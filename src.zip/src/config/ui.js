export const SEAT_W = "w-9 sm:w-10 md:w-11 lg:w-12";
export const SEAT_H = "h-9 sm:h-10 md:h-11 lg:h-12";
export const SEAT_GAP = "gap-2 sm:gap-3";
export const AISLE_W = "w-8 sm:w-10";
export const ROWNUM_W = "w-6 sm:w-8";
