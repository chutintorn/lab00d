// src/utils/pricingConstants.js
export const HOTEL_PRICE_PER_DAY = 1000;
export const TRANSPORT_PRICE = 500;
export const EVENT_PRICE = 800;
