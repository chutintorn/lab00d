import React from "react";

/**
 * Renders one seat row.
 * resolver(col, row) should return:
 *   {
 *     id, bg, selected, highlighted, disabled, isPrivacy, onClick,
 *     priceTHB, showPrices, zoneType, title
 *   }
 */
export default function SeatRow({
  row,
  leftBlock = [],
  rightBlock = [],
  resolver,
  showPrices = false,
}) {
  const hiddenRow1 = new Set(["H", "J", "K"]);

  const renderSeat = (rawCol) => {
    const col = String(rawCol).toUpperCase();

    // Hide H/J/K only for row 1
    if (Number(row) === 1 && hiddenRow1.has(col)) return null;

    const seat = resolver(col, row) || {};
    const {
      id = `${row}${col}`,
      bg = "#ffffff",
      selected = false,
      highlighted = false,
      disabled = false,
      isPrivacy = false,
      onClick = () => {},

      priceTHB = 0,
      showPrices: seatShowPrices,
      title,
    } = seat;

    const shouldShowPrice = (seatShowPrices ?? showPrices) && priceTHB > 0;

    const base =
      "inline-flex flex-col items-center justify-center w-10 h-10 rounded text-sm border transition-colors relative";
    const style = { backgroundColor: bg };

    const privacyInset = isPrivacy
      ? "shadow-[inset_0_0_0_2px_rgba(56,189,248,0.8)]"
      : "";

    const selectedRing = selected ? "ring-2 ring-blue-500 border-blue-500" : "";
    const highlightRing =
      !selected && highlighted ? "ring-2 ring-yellow-400 border-yellow-400" : "";
    const disabledClass = disabled ? "opacity-60 cursor-not-allowed" : "hover:brightness-95";

    const className = [base, privacyInset, selectedRing, highlightRing, disabledClass]
      .filter(Boolean)
      .join(" ");

    const aria = (() => {
      let label = `Seat ${id}`;
      if (shouldShowPrice) label += `, ${priceTHB.toLocaleString("th-TH")} THB`;
      if (isPrivacy) label += " (privacy seat reserved)";
      if (selected) label += " selected";
      return label;
    })();

    return (
      <button
        key={id}
        type="button"
        className={className}
        style={style}
        onClick={onClick}
        disabled={disabled}
        title={title || id}
        aria-label={aria}
        aria-pressed={selected}
      >
        {/* hide seat code text per your preference */}
        {shouldShowPrice && (
          <span className="text-[9px] leading-none text-gray-800">
            {priceTHB.toLocaleString("th-TH")} THB
          </span>
        )}
      </button>
    );
  };

  return (
    <div className="flex items-center gap-3 py-1">
      {/* Row number (left) */}
      <div className="w-8 text-xs text-gray-500 text-right">{row}</div>

      {/* Left seats */}
      <div className="flex gap-2">{leftBlock.map(renderSeat)}</div>

      {/* Aisle */}
      <div className="w-8" />

      {/* Right seats */}
      <div className="flex gap-2">{rightBlock.map(renderSeat)}</div>
    </div>
  );
}
