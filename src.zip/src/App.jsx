import React from "react";
import PassengerBookingUpdateSeat from "./pages/PassengerBookingUpdateSeat";

export default function App() {
  return (
    <div className="min-h-screen">
      <PassengerBookingUpdateSeat />
    </div>
  );
}
