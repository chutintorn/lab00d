export const fontFamily = {
  sans: ['"Noto Sans Thai"', 'ui-sans-serif', 'system-ui'],
  heading: ['"Roboto Slab"', 'serif'],
  mono: ['"Fira Code"', 'monospace'],
};
