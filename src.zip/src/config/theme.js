export const THEME = {
  frontPremium: "#f4bd07ff",
  premium: "#ecd50ee0",
  happy: "#a0ed10ff",
  booked: "#f4f9f5ff",
  unavailable: "#f7e8e8ff",
  selected: "#93c0eeff",
  outline: "#867e0dff",
  privacyRing: "#76b8ff",
  // New page background
  bg50: "#e0f7ff",
};
